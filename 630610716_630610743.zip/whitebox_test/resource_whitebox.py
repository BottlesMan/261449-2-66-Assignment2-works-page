class resource_whitebox:
    # Declare side variables and set default values to 0
    firstSide = 0
    secondSide = 0
    thirdSide = 0

    # Determine which side is the largest
    def largest(self, side1, side2, side3):
        if ((side1 <= side2 and side2 <= side3) or (side2 <= side1 or side1 <= side3)):
            return side3
        elif ((side1 <= side3 and side3 <= side2) or (side3 <= side1 and side1 <= side2)):
            return side2
        else:
            return side1

    # Determine which side is the middle side
    def middle(self, side1, side2, side3):
        if ((side1 <= side2 and side2 <= side3) or (side2 <= side1 and side3 <= side2)):
            return side2
        elif ((side1 <= side3 and side3 <= side2) or (side3 <= side1 and side2 <= side3)):
            return side3
        else:
            return side1

    # Determine which side is the smallest
    def smallest(self, side1, side2, side3):
        if ((side1 <= side2 and side2 <= side3) or (side3 <= side2 and side1 <= side3)):
            return side1
        elif ((side2 <= side3 and side3 <= side1) or (side2 <= side1 and side1 <= side3)):
            return side1
        else:
            return side3

    def findTriangleType(self):
        shortSide = self.smallest(self.firstSide, self.secondSide, self.thirdSide)
        middleSide = self.middle(self.firstSide, self.secondSide, self.thirdSide)
        longSide = self.largest(self.firstSide, self.secondSide, self.thirdSide)
        if shortSide + middleSide < longSide:
            return "Not a Triangle"
        elif shortSide == middleSide and middleSide == longSide:
            return "Equilateral"
        elif shortSide == middleSide or middleSide == longSide:
            return "Isosceles"
        else:
            return "Scalene"

    def __init__(self, side1=0, side2=0, side3=0):
        self.firstSide = side1
        self.secondSide = side2
        self.thirdSide = side3